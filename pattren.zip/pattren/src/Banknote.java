/**
 * Banknote - приспособленец
 * length, width - внутренние характеристики банкнот
 */
public abstract class Banknote {
    protected int length;
    protected int width;
    public abstract void Print(int currencyDenomination);
}
