import java.util.HashMap;
import java.util.Map;

public class BanknoteFactory {
    Map<String, Banknote> banknotes = new HashMap<String, Banknote>();
    public BanknoteFactory() {
        banknotes.put("Euro", new FakeEuro());
        banknotes.put("Dollar", new FakeDollar());
        banknotes.put("Ruble", new FakeRuble());
    }

    public Banknote getBanknote(String name) {
        return banknotes.getOrDefault(name, null);
    }
}
