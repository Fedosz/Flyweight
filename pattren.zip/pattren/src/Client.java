import java.util.Objects;

public class Client {
    final private String id;
    public Client(String name) {
        id = name;
    }
    public void askForExchange(String currency, BanknoteFactory bank, int value) {
        if (bank.getBanknote(currency) == null) {
            System.out.println("Банк не выдаёт валюту " + currency);
            return;
        }
        bank.getBanknote(currency).Print(value);
        System.out.println("Купюра выдана");
    }
}
