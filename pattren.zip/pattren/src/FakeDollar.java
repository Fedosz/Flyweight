public class FakeDollar extends Banknote {
    public FakeDollar () {
        length = 156;
        width = 66;
    }
    @Override
    public void Print(int value) {
        System.out.println("Напечата купюра доллара размерами 156х66 номиналом " + value);
    }
}
