/**
 * Размеры купюры каждой валюты неизменны, изменяется только номинал
 */
public class FakeEuro extends Banknote {
    public FakeEuro () {
        length = 140;
        width = 77;
    }
    @Override
    public void Print(int value) {
        System.out.println("Напечатана купюра евро размерами 140х77 номиналом " + value);
    }
}
