public class FakeRuble extends Banknote {
    public FakeRuble () {
        length = 150;
        width = 65;
    }
    @Override
    public void Print(int value) {
        System.out.println("Напечатана рублёвая купюра размерами 150х65 номиналом " + value);
    }
}
