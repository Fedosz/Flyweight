/**
 * В нашем мире появился настоящий банк приколов, который вадает купюры разных стран
 * Однако особенность в том, что у каждой валюты есть свой размер
 * Но! Номинал валюты может быть абсолютно любой, и он не зависит ни от чего
 * и является "внешней" характеристикой нашей купюры.
 */
public class Main {
    public static void main(String[] args) {
        BanknoteFactory BankOfJokes = new BanknoteFactory();
        Client John = new Client("John");
        John.askForExchange("Euro", BankOfJokes, 100);
        John.askForExchange("Dollar", BankOfJokes, 500);
        John.askForExchange("Ruble", BankOfJokes, 10000000);
        John.askForExchange("Gold", BankOfJokes, 20);
    }
}